package com.anudip.springdemo;

public interface HotDrink {

	public void prepareHotDrink();
}
