package com.anudip.springdemo;

public class Coffe implements HotDrink{

	@Override
	public void prepareHotDrink() {
		System.out.println("Dear Customer, we are preparing coffe for u!!!");
		
	}

}
